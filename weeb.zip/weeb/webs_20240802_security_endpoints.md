

https://javaee.github.io/tutorial/security-webtier002.html
https://dzone.com/refcardz/getting-started-java-ee
https://www.ibm.com/docs/en/was/9.0.5?topic=settings-securing-applications-during-assembly-deployment
https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods
https://stackoverflow.com/questions/8069640/whitelist-security-constraint-in-web-xml
https://docs.oracle.com/cd/B14098_01/web.1012/b15505/packaging004.htm
https://stackoverflow.com/questions/28705463/how-can-i-override-a-security-constraint-within-a-webapp-deployed-to-tomcat
https://heraclitusonsoftware.wordpress.com/software-development/spring/simple-web-application-with-spring-security-part-1/

